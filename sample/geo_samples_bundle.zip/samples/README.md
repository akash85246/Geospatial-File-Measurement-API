# Sample files

Regenerate with `python tools/build_samples.py`; check the API code with `python tools/run_samples.py`.

Lon/lat expectations are approximate (tolerance 0.5%) because the API measures in UTM.

| File | What it tests | Expected output |
|---|---|---|
| `01_valid_mixed.kml` | Happy path. 3 KML folders (= 3 layers), polygon, polygon with a hole, line, point. | 4 features, CRS EPSG:4326. Parcel A area ~11,687 m2, Parcel B ~42,542 m2 (hole subtracted), Road 1 length ~697 m, Well 1 no measurement + note. |
| `02_edge_geometries.kml` | 3D coordinates, self-intersecting polygon, southern hemisphere (UTM south zone), unicode name, MultiGeometry, geometry collection, placemark without geometry. | 3D polygon, southern polygon (~1,026,338 m2) and unicode polygon measured normally. Bowtie is flagged 'Invalid geometry' (its area collapses to ~0, which is why the flag matters). Collection -> 'Unsupported geometry type' note. Placemark with no geometry may be dropped by the driver. Nothing crashes. |
| `03_empty_document.kml` | Valid KML with zero placemarks. | Clean error (HTTP 400), no crash. |
| `04_malformed.kml` | Truncated / invalid XML. | Clean error (HTTP 400). If your GDAL build is lenient it may return partial data instead (WARN). |
| `05_wrong_extension.txt` | Wrong extension. | 'Unsupported file type' error (HTTP 400). |
| `06_same_degrees_different_area.kml` | The CRS trap: identical 0.01 x 0.01 degree squares at different latitudes. | Areas differ a lot: equator ~1,230,907 m2, 69N (Norway) ~446,230 m2, 33.9S (Sydney) ~1,025,984 m2. If all three were equal, you are measuring in degrees. |
| `07_zero_bytes.kml` | 0-byte upload. | 'Uploaded file is empty' error (HTTP 400). |
| `10_utm_projected.zip` | Already-projected Shapefile (UTM 43N, metres) with 3 shapefiles in one zip: polygons, lines, points. Attributes include text, int, float, blank/null values and a date. | 5 features, CRS EPSG:32643, NO reprojection. Exact values: Parcel A 5000 m2, Parcel B 37500 m2 (40000 - 2500 hole), Road 1 500 m, Road 2 300 m, Well 1 note only. Null attributes become null in JSON. |
| `11_wgs84_geographic.zip` | Geographic (lon/lat) Shapefile with the SAME shapes as 01_valid_mixed.kml. | Same numbers as the KML (Parcel A ~11,687 m2, Parcel B ~42,542 m2, Road 1 ~697 m). Shows KML and Shapefile go through the same CRS path. |
| `12_projected_in_feet.zip` | Projected CRS whose unit is FEET (tests the unit conversion). | Lot 1 and Lot 2 are 10,000 ft2 each = 929.03 m2; Fence 1 is 1,000 ft = 304.8 m. If you see 10000 / 1000 the unit factor is being ignored. CRS label falls back to the CRS name (no EPSG code). |
| `13_no_prj_lonlat.zip` | Shapefile with no .prj, coordinates look like lon/lat. | Works, CRS assumed EPSG:4326, each feature gets the note 'CRS missing (.prj not found)... assumed EPSG:4326'. |
| `14_no_prj_projected.zip` | No .prj and metre-scale coordinates (cannot be guessed). | Error 'Shapefile has no CRS (.prj missing)...' (HTTP 400). Refuses to guess. |
| `15_no_shp_inside.zip` | Valid zip but no .shp inside. | Error 'Zip does not contain a .shp file' (HTTP 400). |
| `16_missing_shx.zip` | Incomplete Shapefile: .shx index missing. | Error 'Could not read shapefile' (HTTP 400). GDAL can be configured to rebuild .shx; if yours does, you get WARN with normal results instead. |
| `17_zip_slip.zip` | Malicious zip containing '../evil.txt' (path traversal / zip-slip). | Error 'Zip contains an unsafe path' (HTTP 400). Nothing is written outside the temp dir. |
| `18_corrupt.zip` | Truncated zip (download cut off). | Error 'Invalid or corrupt zip file' (HTTP 400). |
| `19_nested_with_macos_junk.zip` | Shapefile inside a subfolder plus __MACOSX/._ junk files (Mac zips). | 2 features. The junk '._parcels.shp' is ignored, not parsed as a second shapefile. |
| `20_multipart_and_null.zip` | Multi-part shapes and a null shape record: 2-ring polygon (MultiPolygon), a NULL geometry record, 2-part polyline (MultiLineString), MultiPoint. | Two islands area 12500 m2 (summed), Plain 100 m2, Two segments length 150 m (summed), Null record -> geometry_type 'Empty' + note, Cluster -> note only. |
| `21_mixed_crs.zip` | Two shapefiles in one zip with DIFFERENT CRSs (lon/lat and UTM). | Each feature measured in its own CRS (areas ~ lon/lat values, roads 500 m / 300 m). File-level crs = 'MIXED'; each feature keeps its own crs label. |
