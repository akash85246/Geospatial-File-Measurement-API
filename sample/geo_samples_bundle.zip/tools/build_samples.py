#!/usr/bin/env python3
"""Build sample KML / zipped-Shapefile inputs for the measurement API.

Standard library only (no GDAL / GeoPandas needed), so it runs anywhere:

    python tools/build_samples.py

Writes ./samples/*, plus samples/expected.json (used by tools/run_samples.py)
and samples/README.md (what each file tests and what output to expect).
"""
from __future__ import annotations

import json
import math
import struct
import zipfile
from datetime import date
from pathlib import Path
from xml.sax.saxutils import escape

OUT = Path(__file__).resolve().parent.parent / "samples"

# =============================================================== expected ====
# Reference values come from a local tangent-plane calculation on the WGS84
# ellipsoid. The API measures in UTM, whose scale factor deviates from 1 by up
# to ~0.1% (area ~0.2%) near zone edges, so lon/lat comparisons use 0.5% tolerance.
A_WGS84 = 6378137.0
E2 = (1 / 298.257223563) * (2 - 1 / 298.257223563)
GEO_REL_TOL = 0.005


def _local_xy(points):
    lon0 = sum(p[0] for p in points) / len(points)
    lat0 = sum(p[1] for p in points) / len(points)
    phi = math.radians(lat0)
    w = 1 - E2 * math.sin(phi) ** 2
    n_radius = A_WGS84 / math.sqrt(w)
    m_radius = A_WGS84 * (1 - E2) / w ** 1.5
    kx = math.radians(1) * n_radius * math.cos(phi)
    ky = math.radians(1) * m_radius
    return lambda p: ((p[0] - lon0) * kx, (p[1] - lat0) * ky)


def _shoelace(xy):
    s = 0.0
    for (x1, y1), (x2, y2) in zip(xy, xy[1:] + xy[:1]):
        s += x1 * y2 - x2 * y1
    return abs(s) / 2


def geo_area(outer, holes=()):
    f = _local_xy(outer)
    area = _shoelace([f(p) for p in outer])
    for h in holes:
        area -= _shoelace([f(p) for p in h])
    return area


def geo_length(pts):
    f = _local_xy(pts)
    xy = [f(p) for p in pts]
    return sum(math.dist(a, b) for a, b in zip(xy, xy[1:]))


def rect(x0, y0, x1, y1):
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)]


def exp(name, mtype=None, value=None, rel=None, abs_=None, gtype=None,
        note=None, info=False, optional=False):
    d = {"name": name, "measurement_type": mtype}
    if value is not None:
        d["value"] = value
    if rel is not None:
        d["rel_tol"] = rel
    if abs_ is not None:
        d["abs_tol"] = abs_
    if gtype:
        d["geometry_type"] = gtype
    if note:
        d["note_contains"] = note
    if info:
        d["info_only"] = True
    if optional:
        d["optional"] = True
    return d


def ok(features, crs_any=None, file_crs=None, count=None):
    d = {"outcome": "ok", "features": features}
    if crs_any:
        d["crs_contains_any"] = crs_any
    if file_crs:
        d["file_crs"] = file_crs
    d["feature_count"] = count if count is not None else None
    return d


def err(contains, soft=False):
    return {"outcome": "error", "error_contains": contains, "soft": soft}


EXPECTED: dict = {}
DESCRIPTIONS: dict = {}


def describe(fname, tests, expected):
    DESCRIPTIONS[fname] = (tests, expected)


# ================================================================ KML ========
def kml_coords(pts):
    return " ".join(",".join(f"{v:.7f}" for v in p) for p in pts)


def kml_polygon(outer, holes=()):
    inner = "".join(
        f"<innerBoundaryIs><LinearRing><coordinates>{kml_coords(h)}</coordinates></LinearRing></innerBoundaryIs>"
        for h in holes
    )
    return (f"<Polygon><outerBoundaryIs><LinearRing><coordinates>{kml_coords(outer)}"
            f"</coordinates></LinearRing></outerBoundaryIs>{inner}</Polygon>")


def kml_line(pts):
    return f"<LineString><coordinates>{kml_coords(pts)}</coordinates></LineString>"


def kml_point(p):
    return f"<Point><coordinates>{kml_coords([p])}</coordinates></Point>"


def placemark(name, geom_xml="", desc=None, extended=None):
    d = f"<description>{escape(desc)}</description>" if desc else ""
    ext = ""
    if extended:
        ext = "<ExtendedData>" + "".join(
            f'<Data name="{escape(k)}"><value>{escape(str(v))}</value></Data>'
            for k, v in extended.items()) + "</ExtendedData>"
    return f"<Placemark><name>{escape(name)}</name>{d}{ext}{geom_xml}</Placemark>\n"


def kml_doc(title, body):
    return ('<?xml version="1.0" encoding="UTF-8"?>\n'
            '<kml xmlns="http://www.opengis.net/kml/2.2">\n<Document>\n'
            f"<name>{escape(title)}</name>\n{body}</Document>\n</kml>\n")


def folder(name, body):
    return f"<Folder><name>{escape(name)}</name>\n{body}</Folder>\n"


# ---- shared lon/lat geometry (Pune area) ----
PARCEL_A = rect(73.8500, 18.5200, 73.8510, 18.5210)
PARCEL_B_OUT = rect(73.8520, 18.5200, 73.8540, 18.5220)
PARCEL_B_HOLE = rect(73.8527, 18.5207, 73.8533, 18.5213)
ROAD_1_LL = [(73.8500, 18.5230), (73.8520, 18.5230), (73.8520, 18.5250), (73.8545, 18.5250)]
WELL_1_LL = (73.8505, 18.5205)

AREA_A = geo_area(PARCEL_A)
AREA_B = geo_area(PARCEL_B_OUT, [PARCEL_B_HOLE])
LEN_ROAD1 = geo_length(ROAD_1_LL)


def build_kmls():
    OUT.mkdir(parents=True, exist_ok=True)

    # 01 happy path: three folders -> three layers, all three geometry types
    body = (
        folder("Parcels",
               placemark("Parcel A", kml_polygon(PARCEL_A), desc="North plot", extended={"owner": "Asha Rao"})
               + placemark("Parcel B (with hole)", kml_polygon(PARCEL_B_OUT, [PARCEL_B_HOLE])))
        + folder("Roads", placemark("Road 1", kml_line(ROAD_1_LL)))
        + folder("Wells", placemark("Well 1", kml_point(WELL_1_LL)))
    )
    (OUT / "01_valid_mixed.kml").write_text(kml_doc("Pune survey sample", body), encoding="utf-8")
    EXPECTED["01_valid_mixed.kml"] = ok([
        exp("Parcel A", "area", AREA_A, rel=GEO_REL_TOL, gtype="Polygon"),
        exp("Parcel B (with hole)", "area", AREA_B, rel=GEO_REL_TOL, gtype="Polygon"),
        exp("Road 1", "length", LEN_ROAD1, rel=GEO_REL_TOL, gtype="LineString"),
        exp("Well 1", None, gtype="Point", note="No measurement"),
    ], crs_any=["EPSG:4326"], count=4)
    describe("01_valid_mixed.kml",
             "Happy path. 3 KML folders (= 3 layers), polygon, polygon with a hole, line, point.",
             f"4 features, CRS EPSG:4326. Parcel A area ~{AREA_A:,.0f} m2, Parcel B ~{AREA_B:,.0f} m2 "
             f"(hole subtracted), Road 1 length ~{LEN_ROAD1:,.0f} m, Well 1 no measurement + note.")

    # 02 edge geometries
    tri_3d = [(73.8600, 18.5300, 100), (73.8610, 18.5300, 105), (73.8610, 18.5310, 110),
              (73.8600, 18.5310, 100), (73.8600, 18.5300, 100)]
    tri_3d_2d = [(x, y) for x, y, _ in tri_3d]
    bowtie = [(73.8800, 18.5300), (73.8810, 18.5310), (73.8810, 18.5300), (73.8800, 18.5310), (73.8800, 18.5300)]
    south = rect(151.2000, -33.8700, 151.2100, -33.8600)
    uni_name = "हिन्दी 測試 ñ"
    uni = rect(73.8700, 18.5300, 73.8705, 18.5305)
    body = (
        placemark("3D polygon (has altitude)", kml_polygon(tri_3d))
        + placemark("Bowtie (self-intersecting)", kml_polygon(bowtie))
        + placemark("Southern hemisphere polygon", kml_polygon(south))
        + placemark(uni_name, kml_polygon(uni))
        + placemark("Two-part line", "<MultiGeometry>" + kml_line([(73.86, 18.54), (73.861, 18.54)])
                    + kml_line([(73.862, 18.54), (73.862, 18.541)]) + "</MultiGeometry>")
        + placemark("Point + line collection", "<MultiGeometry>" + kml_point((73.86, 18.55))
                    + kml_line([(73.86, 18.55), (73.861, 18.55)]) + "</MultiGeometry>")
        + placemark("No geometry at all")
    )
    (OUT / "02_edge_geometries.kml").write_text(kml_doc("Edge cases", body), encoding="utf-8")
    EXPECTED["02_edge_geometries.kml"] = ok([
        exp("3D polygon (has altitude)", "area", geo_area(tri_3d_2d), rel=GEO_REL_TOL, gtype="Polygon"),
        exp("Bowtie (self-intersecting)", None, note="Invalid geometry", info=True),
        exp("Southern hemisphere polygon", "area", geo_area(south), rel=GEO_REL_TOL, gtype="Polygon"),
        exp(uni_name, "area", geo_area(uni), rel=GEO_REL_TOL, gtype="Polygon"),
        exp("Two-part line", info=True),
        exp("Point + line collection", info=True),
        exp("No geometry at all", info=True, optional=True),
    ], crs_any=["EPSG:4326"])
    describe("02_edge_geometries.kml",
             "3D coordinates, self-intersecting polygon, southern hemisphere (UTM south zone), "
             "unicode name, MultiGeometry, geometry collection, placemark without geometry.",
             f"3D polygon, southern polygon (~{geo_area(south):,.0f} m2) and unicode polygon measured normally. "
             "Bowtie is flagged 'Invalid geometry' (its area collapses to ~0, which is why the flag matters). "
             "Collection -> 'Unsupported geometry type' note. Placemark with no geometry may be dropped by the "
             "driver. Nothing crashes.")

    # 03 / 04 / 05 / 07 bad inputs
    (OUT / "03_empty_document.kml").write_text(kml_doc("Nothing here", ""), encoding="utf-8")
    EXPECTED["03_empty_document.kml"] = err(["no layers", "No features", "Could not read"])
    describe("03_empty_document.kml", "Valid KML with zero placemarks.", "Clean error (HTTP 400), no crash.")

    broken = ('<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document>'
              "<Placemark><name>Broken</name><Polygon><outerBoundaryIs><LinearRing><coordinates>"
              "73.85,18.52 73.86,18.52 73.86")
    (OUT / "04_malformed.kml").write_text(broken, encoding="utf-8")
    EXPECTED["04_malformed.kml"] = err(["Could not read", "No features", "no layers"], soft=True)
    describe("04_malformed.kml", "Truncated / invalid XML.",
             "Clean error (HTTP 400). If your GDAL build is lenient it may return partial data instead (WARN).")

    (OUT / "05_wrong_extension.txt").write_text("this is not a geospatial file\n")
    EXPECTED["05_wrong_extension.txt"] = err(["Unsupported file type"])
    describe("05_wrong_extension.txt", "Wrong extension.", "'Unsupported file type' error (HTTP 400).")

    (OUT / "07_zero_bytes.kml").write_bytes(b"")
    EXPECTED["07_zero_bytes.kml"] = err(["empty"])
    describe("07_zero_bytes.kml", "0-byte upload.", "'Uploaded file is empty' error (HTTP 400).")

    # 06 CRS trap: same 0.01 x 0.01 degree square at three places
    sq = [("Square at equator", rect(0.0, 0.0, 0.01, 0.01)),
          ("Square at 69N (Norway)", rect(19.0, 69.0, 19.01, 69.01)),
          ("Square at 33.9S (Sydney)", rect(151.2, -33.9, 151.21, -33.89))]
    body = "".join(placemark(n, kml_polygon(r)) for n, r in sq)
    (OUT / "06_same_degrees_different_area.kml").write_text(kml_doc("CRS trap", body), encoding="utf-8")
    EXPECTED["06_same_degrees_different_area.kml"] = ok(
        [exp(n, "area", geo_area(r), rel=GEO_REL_TOL, gtype="Polygon") for n, r in sq],
        crs_any=["EPSG:4326"], count=3)
    describe("06_same_degrees_different_area.kml",
             "The CRS trap: identical 0.01 x 0.01 degree squares at different latitudes.",
             "Areas differ a lot: " + ", ".join(f"{n.split(' at ')[1]} ~{geo_area(r):,.0f} m2" for n, r in sq)
             + ". If all three were equal, you are measuring in degrees.")


# ============================================================ Shapefile ======
SHAPE_TYPE = {"point": 1, "polyline": 3, "polygon": 5, "multipoint": 8}
GEOGCS = ('GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137.0,298.257223563]],'
          'PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]')


def _projcs(name, false_easting, unit_name, unit_factor):
    return (f'PROJCS["{name}",{GEOGCS},PROJECTION["Transverse_Mercator"],'
            f'PARAMETER["False_Easting",{false_easting}],PARAMETER["False_Northing",0.0],'
            f'PARAMETER["Central_Meridian",75.0],PARAMETER["Scale_Factor",0.9996],'
            f'PARAMETER["Latitude_Of_Origin",0.0],UNIT["{unit_name}",{unit_factor}]]')


PRJ_WGS84 = GEOGCS
PRJ_UTM43N = _projcs("WGS_1984_UTM_Zone_43N", "500000.0", "Meter", "1.0")
FT = 0.3048
PRJ_UTM43N_FEET = _projcs("WGS_1984_UTM_Zone_43N_Feet", repr(500000.0 / FT), "Foot", "0.3048")


def _signed_area(r):
    return sum(x1 * y2 - x2 * y1 for (x1, y1), (x2, y2) in zip(r, r[1:])) / 2


def poly_rings(outer, holes=()):
    """Shapefile rule: outer rings clockwise, holes counter-clockwise."""
    o = list(outer)
    if _signed_area(o) > 0:
        o.reverse()
    rings = [o]
    for h in holes:
        h = list(h)
        if _signed_area(h) < 0:
            h.reverse()
        rings.append(h)
    return rings


def _points_of(kind, geom):
    if geom is None:
        return []
    if kind == "point":
        return [geom]
    if kind == "multipoint":
        return list(geom)
    return [p for part in geom for p in part]


def _bbox(pts):
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    return (min(xs), min(ys), max(xs), max(ys))


def _content(kind, geom):
    t = SHAPE_TYPE[kind]
    if geom is None:
        return struct.pack("<i", 0)  # null shape
    if kind == "point":
        return struct.pack("<i2d", t, *geom)
    pts = _points_of(kind, geom)
    if kind == "multipoint":
        return (struct.pack("<i4di", t, *_bbox(pts), len(pts))
                + b"".join(struct.pack("<2d", *p) for p in pts))
    starts, n = [], 0
    for part in geom:
        starts.append(n)
        n += len(part)
    return (struct.pack("<i4dii", t, *_bbox(pts), len(geom), len(pts))
            + struct.pack(f"<{len(starts)}i", *starts)
            + b"".join(struct.pack("<2d", *p) for p in pts))


def _header(total_bytes, shape_type, bbox):
    return (struct.pack(">7i", 9994, 0, 0, 0, 0, 0, total_bytes // 2)
            + struct.pack("<2i", 1000, shape_type)
            + struct.pack("<8d", *bbox, 0.0, 0.0, 0.0, 0.0))


def build_shp_shx(kind, geoms):
    shp_body = shx_body = b""
    allpts, offset = [], 100
    for i, g in enumerate(geoms, 1):
        c = _content(kind, g)
        shx_body += struct.pack(">2i", offset // 2, len(c) // 2)
        shp_body += struct.pack(">2i", i, len(c) // 2) + c
        offset += 8 + len(c)
        allpts += _points_of(kind, g)
    bbox = _bbox(allpts) if allpts else (0.0, 0.0, 0.0, 0.0)
    t = SHAPE_TYPE[kind]
    return (_header(100 + len(shp_body), t, bbox) + shp_body,
            _header(100 + len(shx_body), t, bbox) + shx_body)


def build_dbf(fields, rows):
    """fields: (name, type 'C'|'N'|'D', width, decimals). rows: list of value lists."""
    hdr_len = 32 + 32 * len(fields) + 1
    rec_len = 1 + sum(f[2] for f in fields)
    out = struct.pack("<4BIHH20x", 3, 126, 10, 8, len(rows), hdr_len, rec_len)
    for name, typ, width, dec in fields:
        out += name.encode()[:10].ljust(11, b"\0") + typ.encode() + b"\0" * 4 + bytes([width, dec]) + b"\0" * 14
    out += b"\x0d"
    for row in rows:
        rec = b" "
        for (name, typ, width, dec), v in zip(fields, row):
            if typ == "C":
                rec += ("" if v is None else str(v)).encode("utf-8")[:width].ljust(width)
            elif typ == "N":
                if v is None:
                    rec += b" " * width
                elif dec:
                    rec += f"{v:.{dec}f}".rjust(width).encode()
                else:
                    rec += str(int(v)).rjust(width).encode()
            elif typ == "D":
                rec += b" " * 8 if v is None else v.strftime("%Y%m%d").encode()
        out += rec
    return out + b"\x1a"


def shp_entries(stem, kind, geoms, fields, rows, prj=None, prefix="", drop=()):
    shp, shx = build_shp_shx(kind, geoms)
    files = {"shp": shp, "shx": shx, "dbf": build_dbf(fields, rows), "cpg": b"UTF-8"}
    if prj:
        files["prj"] = prj.encode()
    return {f"{prefix}{stem}.{ext}": data for ext, data in files.items() if ext not in drop}


def write_zip(fname, entries, extra=None):
    with zipfile.ZipFile(OUT / fname, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in entries.items():
            zf.writestr(name, data)
        for info, data in (extra or []):
            zf.writestr(info, data)


NAME30 = ("NAME", "C", 30, 0)
PARCEL_FIELDS = [NAME30, ("PARCEL_ID", "N", 10, 0), ("OWNER", "C", 30, 0), ("VALUE", "N", 12, 2), ("SURVEYED", "D", 8, 0)]
PARCEL_ROWS = [["Parcel A", 1, "Asha Rao", 125000.50, date(2025, 3, 14)],
               ["Parcel B", 2, "", None, None]]  # blank owner, null value, null date
ROAD_FIELDS = [NAME30, ("LANES", "N", 4, 0)]
WELL_FIELDS = [NAME30, ("DEPTH_M", "N", 8, 1)]


def parcels_ll(prj, prefix="", stem="parcels", drop=()):
    return shp_entries(stem, "polygon",
                       [poly_rings(PARCEL_A), poly_rings(PARCEL_B_OUT, [PARCEL_B_HOLE])],
                       PARCEL_FIELDS, PARCEL_ROWS, prj, prefix, drop)


# ---- UTM 43N metre geometry: exact, hand-checkable numbers ----
E0, N0 = 500000.0, 2050000.0
U_PARCEL_A = rect(E0, N0, E0 + 100, N0 + 50)                         # 5,000 m2
U_PARCEL_B = rect(E0 + 300, N0, E0 + 500, N0 + 200)                  # 40,000 m2
U_PARCEL_B_HOLE = rect(E0 + 350, N0 + 50, E0 + 400, N0 + 100)        # -2,500 m2
U_ROAD_1 = [(E0, N0 + 100), (E0 + 300, N0 + 500)]                    # 3-4-5 triangle -> 500 m
U_ROAD_2 = [(E0, N0 + 600), (E0 + 100, N0 + 600), (E0 + 100, N0 + 800)]  # 100 + 200 = 300 m
U_WELL = (E0 + 50, N0 + 25)


def parcels_utm(prj, prefix="", drop=()):
    return shp_entries("parcels", "polygon",
                       [poly_rings(U_PARCEL_A), poly_rings(U_PARCEL_B, [U_PARCEL_B_HOLE])],
                       PARCEL_FIELDS, PARCEL_ROWS, prj, prefix, drop)


def roads_utm(prj, prefix="", stem="roads"):
    return shp_entries(stem, "polyline", [[U_ROAD_1], [U_ROAD_2]], ROAD_FIELDS,
                       [["Road 1", 2], ["Road 2", 1]], prj, prefix)


def build_shapefiles():
    # 10 projected, exact numbers
    entries = {}
    entries.update(parcels_utm(PRJ_UTM43N))
    entries.update(roads_utm(PRJ_UTM43N))
    entries.update(shp_entries("wells", "point", [U_WELL], WELL_FIELDS, [["Well 1", 42.5]], PRJ_UTM43N))
    write_zip("10_utm_projected.zip", entries)
    EXPECTED["10_utm_projected.zip"] = ok([
        exp("Parcel A", "area", 5000.0, abs_=0.01, gtype="Polygon"),
        exp("Parcel B", "area", 37500.0, abs_=0.01, gtype="Polygon"),
        exp("Road 1", "length", 500.0, abs_=0.01, gtype="LineString"),
        exp("Road 2", "length", 300.0, abs_=0.01, gtype="LineString"),
        exp("Well 1", None, gtype="Point", note="No measurement"),
    ], crs_any=["32643", "UTM_Zone_43N"], count=5)
    describe("10_utm_projected.zip",
             "Already-projected Shapefile (UTM 43N, metres) with 3 shapefiles in one zip: polygons, lines, points. "
             "Attributes include text, int, float, blank/null values and a date.",
             "5 features, CRS EPSG:32643, NO reprojection. Exact values: Parcel A 5000 m2, Parcel B 37500 m2 "
             "(40000 - 2500 hole), Road 1 500 m, Road 2 300 m, Well 1 note only. Null attributes become null in JSON.")

    # 11 geographic shapefile = same shapes as the KML
    entries = {}
    entries.update(parcels_ll(PRJ_WGS84))
    entries.update(shp_entries("roads", "polyline", [[ROAD_1_LL]], ROAD_FIELDS, [["Road 1", 2]], PRJ_WGS84))
    entries.update(shp_entries("wells", "point", [WELL_1_LL], WELL_FIELDS, [["Well 1", 42.5]], PRJ_WGS84))
    write_zip("11_wgs84_geographic.zip", entries)
    EXPECTED["11_wgs84_geographic.zip"] = ok([
        exp("Parcel A", "area", AREA_A, rel=GEO_REL_TOL, gtype="Polygon"),
        exp("Parcel B", "area", AREA_B, rel=GEO_REL_TOL, gtype="Polygon"),
        exp("Road 1", "length", LEN_ROAD1, rel=GEO_REL_TOL, gtype="LineString"),
        exp("Well 1", None, gtype="Point", note="No measurement"),
    ], crs_any=["EPSG:4326"], count=4)
    describe("11_wgs84_geographic.zip",
             "Geographic (lon/lat) Shapefile with the SAME shapes as 01_valid_mixed.kml.",
             "Same numbers as the KML (Parcel A ~%s m2, Parcel B ~%s m2, Road 1 ~%s m). Shows KML and Shapefile "
             "go through the same CRS path." % (f"{AREA_A:,.0f}", f"{AREA_B:,.0f}", f"{LEN_ROAD1:,.0f}"))

    # 12 feet
    n_ft = N0 / FT
    e_ft = 500000.0 / FT
    lot1 = rect(e_ft, n_ft, e_ft + 100, n_ft + 100)
    lot2 = rect(e_ft + 200, n_ft, e_ft + 400, n_ft + 50)
    fence = [(e_ft, n_ft + 300), (e_ft + 1000, n_ft + 300)]
    entries = {}
    entries.update(shp_entries("lots", "polygon", [poly_rings(lot1), poly_rings(lot2)], [NAME30],
                               [["Lot 1"], ["Lot 2"]], PRJ_UTM43N_FEET))
    entries.update(shp_entries("fence", "polyline", [[fence]], [NAME30], [["Fence 1"]], PRJ_UTM43N_FEET))
    write_zip("12_projected_in_feet.zip", entries)
    sqft = 100 * 100 * FT * FT
    EXPECTED["12_projected_in_feet.zip"] = ok([
        exp("Lot 1", "area", sqft, rel=1e-6, gtype="Polygon"),
        exp("Lot 2", "area", 200 * 50 * FT * FT, rel=1e-6, gtype="Polygon"),
        exp("Fence 1", "length", 1000 * FT, rel=1e-6, gtype="LineString"),
    ], count=3)
    describe("12_projected_in_feet.zip",
             "Projected CRS whose unit is FEET (tests the unit conversion).",
             "Lot 1 and Lot 2 are 10,000 ft2 each = 929.03 m2; Fence 1 is 1,000 ft = 304.8 m. "
             "If you see 10000 / 1000 the unit factor is being ignored. CRS label falls back to the CRS name "
             "(no EPSG code).")

    # 13 no .prj but lon/lat
    write_zip("13_no_prj_lonlat.zip", parcels_ll(None, drop=("prj",)))
    EXPECTED["13_no_prj_lonlat.zip"] = ok([
        exp("Parcel A", "area", AREA_A, rel=GEO_REL_TOL, note="assumed EPSG:4326"),
        exp("Parcel B", "area", AREA_B, rel=GEO_REL_TOL, note="assumed EPSG:4326"),
    ], crs_any=["EPSG:4326"], count=2)
    describe("13_no_prj_lonlat.zip", "Shapefile with no .prj, coordinates look like lon/lat.",
             "Works, CRS assumed EPSG:4326, each feature gets the note 'CRS missing (.prj not found)... assumed EPSG:4326'.")

    # 14 no .prj and projected coords
    write_zip("14_no_prj_projected.zip", parcels_utm(None, drop=("prj",)))
    EXPECTED["14_no_prj_projected.zip"] = err(["no CRS"])
    describe("14_no_prj_projected.zip", "No .prj and metre-scale coordinates (cannot be guessed).",
             "Error 'Shapefile has no CRS (.prj missing)...' (HTTP 400). Refuses to guess.")

    # 15 zip without shp
    write_zip("15_no_shp_inside.zip", {"readme.txt": b"hello", "data.geojson": b'{"type":"FeatureCollection","features":[]}'})
    EXPECTED["15_no_shp_inside.zip"] = err(["does not contain a .shp"])
    describe("15_no_shp_inside.zip", "Valid zip but no .shp inside.", "Error 'Zip does not contain a .shp file' (HTTP 400).")

    # 16 missing .shx
    write_zip("16_missing_shx.zip", parcels_utm(PRJ_UTM43N, drop=("shx",)))
    EXPECTED["16_missing_shx.zip"] = err(["Could not read shapefile"], soft=True)
    describe("16_missing_shx.zip", "Incomplete Shapefile: .shx index missing.",
             "Error 'Could not read shapefile' (HTTP 400). GDAL can be configured to rebuild .shx; if yours does, "
             "you get WARN with normal results instead.")

    # 17 zip slip
    entries = parcels_utm(PRJ_UTM43N)
    write_zip("17_zip_slip.zip", entries, extra=[(zipfile.ZipInfo("../evil.txt"), b"pwned")])
    EXPECTED["17_zip_slip.zip"] = err(["unsafe path"])
    describe("17_zip_slip.zip", "Malicious zip containing '../evil.txt' (path traversal / zip-slip).",
             "Error 'Zip contains an unsafe path' (HTTP 400). Nothing is written outside the temp dir.")

    # 18 corrupt zip (truncated copy of 10)
    raw = (OUT / "10_utm_projected.zip").read_bytes()
    (OUT / "18_corrupt.zip").write_bytes(raw[: int(len(raw) * 0.55)])
    EXPECTED["18_corrupt.zip"] = err(["corrupt"])
    describe("18_corrupt.zip", "Truncated zip (download cut off).", "Error 'Invalid or corrupt zip file' (HTTP 400).")

    # 19 nested folders + macOS junk
    entries = parcels_ll(PRJ_WGS84, prefix="survey_2025/")
    entries["__MACOSX/survey_2025/._parcels.shp"] = b"\x00\x05\x16\x07\x00\x02\x00\x00Mac OS X"
    entries["survey_2025/.DS_Store"] = b"\x00\x00\x00\x01Bud1"
    write_zip("19_nested_with_macos_junk.zip", entries)
    EXPECTED["19_nested_with_macos_junk.zip"] = ok([
        exp("Parcel A", "area", AREA_A, rel=GEO_REL_TOL),
        exp("Parcel B", "area", AREA_B, rel=GEO_REL_TOL),
    ], crs_any=["EPSG:4326"], count=2)
    describe("19_nested_with_macos_junk.zip", "Shapefile inside a subfolder plus __MACOSX/._ junk files (Mac zips).",
             "2 features. The junk '._parcels.shp' is ignored, not parsed as a second shapefile.")

    # 20 multipart / null / multipoint
    isl_a = rect(E0, N0, E0 + 100, N0 + 100)
    isl_b = rect(E0 + 300, N0, E0 + 350, N0 + 50)
    entries = {}
    entries.update(shp_entries("multipoly", "polygon",
                               [poly_rings(isl_a) + poly_rings(isl_b), None, poly_rings(rect(E0, N0 + 500, E0 + 10, N0 + 510))],
                               [NAME30], [["Two islands"], ["Null record"], ["Plain"]], PRJ_UTM43N))
    entries.update(shp_entries("multiline", "polyline",
                               [[[(E0, N0), (E0 + 100, N0)], [(E0 + 200, N0), (E0 + 200, N0 + 50)]]],
                               [NAME30], [["Two segments"]], PRJ_UTM43N))
    entries.update(shp_entries("multipoint", "multipoint",
                               [[(E0, N0), (E0 + 10, N0 + 10), (E0 + 20, N0 + 20)]],
                               [NAME30], [["Cluster"]], PRJ_UTM43N))
    write_zip("20_multipart_and_null.zip", entries)
    EXPECTED["20_multipart_and_null.zip"] = ok([
        exp("Two islands", "area", 12500.0, abs_=0.01, info=False),
        exp("Null record", None, gtype="Empty", note="Empty"),
        exp("Plain", "area", 100.0, abs_=0.01, gtype="Polygon"),
        exp("Two segments", "length", 150.0, abs_=0.01),
        exp("Cluster", None, note="No measurement"),
    ], count=5)
    describe("20_multipart_and_null.zip",
             "Multi-part shapes and a null shape record: 2-ring polygon (MultiPolygon), a NULL geometry record, "
             "2-part polyline (MultiLineString), MultiPoint.",
             "Two islands area 12500 m2 (summed), Plain 100 m2, Two segments length 150 m (summed), "
             "Null record -> geometry_type 'Empty' + note, Cluster -> note only.")

    # 21 mixed CRS
    entries = {}
    entries.update(parcels_ll(PRJ_WGS84, stem="parcels_lonlat"))
    entries.update(roads_utm(PRJ_UTM43N, stem="roads_utm"))
    write_zip("21_mixed_crs.zip", entries)
    EXPECTED["21_mixed_crs.zip"] = ok([
        exp("Parcel A", "area", AREA_A, rel=GEO_REL_TOL),
        exp("Parcel B", "area", AREA_B, rel=GEO_REL_TOL),
        exp("Road 1", "length", 500.0, abs_=0.01),
        exp("Road 2", "length", 300.0, abs_=0.01),
    ], file_crs="MIXED", count=4)
    describe("21_mixed_crs.zip", "Two shapefiles in one zip with DIFFERENT CRSs (lon/lat and UTM).",
             "Each feature measured in its own CRS (areas ~ lon/lat values, roads 500 m / 300 m). File-level crs = 'MIXED'; "
             "each feature keeps its own crs label.")


def write_readme():
    lines = ["# Sample files", "",
             "Regenerate with `python tools/build_samples.py`; check the API code with `python tools/run_samples.py`.", "",
             "Lon/lat expectations are approximate (tolerance 0.5%) because the API measures in UTM.", "",
             "| File | What it tests | Expected output |", "|---|---|---|"]
    for fname in sorted(DESCRIPTIONS):
        t, e = DESCRIPTIONS[fname]
        lines.append(f"| `{fname}` | {t} | {e} |")
    (OUT / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    build_kmls()
    build_shapefiles()
    (OUT / "expected.json").write_text(json.dumps(EXPECTED, indent=2, ensure_ascii=False), encoding="utf-8")
    write_readme()
    for p in sorted(OUT.iterdir()):
        print(f"{p.name:42s} {p.stat().st_size:>7,d} bytes")


if __name__ == "__main__":
    main()
