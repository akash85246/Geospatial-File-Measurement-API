#!/usr/bin/env python3
"""Run app.services.process_file over every sample and compare with samples/expected.json.

Run from the repo root (the folder that contains app/, samples/ and tools/):

    python tools/run_samples.py            # summary per file
    python tools/run_samples.py -v         # also print every feature
    python tools/run_samples.py 10_ 02_    # only files whose name starts with these

Status per file:  PASS  = matches expectations
                  WARN  = differs only where GDAL behaviour is driver/version dependent
                  FAIL  = real mismatch or an unhandled exception
Exit code is 1 if anything FAILs.
"""
from __future__ import annotations

import io
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.services import ParserError, process_file  # noqa: E402

SAMPLES = ROOT / "samples"


class FakeUpload:
    """Mimics FastAPI's UploadFile (.filename and .file)."""

    def __init__(self, filename, fileobj):
        self.filename = filename
        self.file = fileobj


class ZeroStream:
    def __init__(self, total):
        self.left = total

    def read(self, n=-1):
        n = self.left if n is None or n < 0 else min(n, self.left)
        self.left -= n
        return b"\0" * n


def run_one(filename, fileobj):
    try:
        feats, crs = process_file(FakeUpload(filename, fileobj))
        return "ok", feats, crs, None
    except ParserError as exc:
        return "error", None, None, str(exc)
    except Exception as exc:  # anything else = unhandled -> bug
        return "crash", None, None, f"{type(exc).__name__}: {exc}"


def feature_name(f):
    props = f.get("properties") or {}
    for k, v in props.items():
        if k.lower() == "name":
            return v
    return None


def fmt_measure(f):
    if f["measurement_value"] is None:
        return "-"
    return f"{f['measurement_type']} {f['measurement_value']:,.4f} {f['measurement_unit']}"


def within(got, exp):
    tol = max(exp.get("abs_tol", 0.0), exp.get("rel_tol", 0.0) * abs(exp["value"]))
    return abs(got - exp["value"]) <= tol


def evaluate(exp, outcome, feats, crs, err):
    """Return (fails, warns, infos) lists of strings."""
    fails, warns, infos = [], [], []
    soft = exp.get("soft", False)

    if exp["outcome"] == "error":
        if outcome == "ok":
            (warns if soft else fails).append("expected an error but processing succeeded")
        elif outcome == "crash":
            fails.append(f"unhandled exception (should be ParserError): {err}")
        elif not any(s.lower() in err.lower() for s in exp["error_contains"]):
            fails.append(f"error text {err!r} does not mention any of {exp['error_contains']}")
        return fails, warns, infos

    if outcome != "ok":
        fails.append(f"expected success, got {outcome}: {err}")
        return fails, warns, infos

    if exp.get("feature_count") is not None and len(feats) != exp["feature_count"]:
        fails.append(f"feature_count {len(feats)} != {exp['feature_count']}")
    if exp.get("file_crs") and crs != exp["file_crs"]:
        fails.append(f"file crs {crs!r} != {exp['file_crs']!r}")
    if exp.get("crs_contains_any") and not any(s in (crs or "") for s in exp["crs_contains_any"]):
        warns.append(f"crs label {crs!r} does not contain any of {exp['crs_contains_any']}")

    by_name = {feature_name(f): f for f in feats}
    for e in exp["features"]:
        name, info = e["name"], e.get("info_only", False)
        f = by_name.get(name)
        if f is None:
            if e.get("optional"):
                infos.append(f"{name!r}: absent (driver dropped it)")
            else:
                fails.append(f"feature {name!r} missing from output")
            continue
        sink = infos if info else fails
        if "geometry_type" in e and f["geometry_type"] != e["geometry_type"]:
            sink.append(f"{name!r}: geometry_type {f['geometry_type']} != {e['geometry_type']}")
        if info:
            infos.append(f"{name!r}: {f['geometry_type']}, {fmt_measure(f)}, note={f['note']!r}")
            continue
        if e.get("measurement_type") != f["measurement_type"]:
            fails.append(f"{name!r}: measurement_type {f['measurement_type']} != {e.get('measurement_type')}")
        elif "value" in e and (f["measurement_value"] is None or not within(f["measurement_value"], e)):
            fails.append(f"{name!r}: value {f['measurement_value']} not within tolerance of {e['value']:,.4f}")
        if "note_contains" in e and e["note_contains"].lower() not in (f["note"] or "").lower():
            fails.append(f"{name!r}: note {f['note']!r} should contain {e['note_contains']!r}")
    return fails, warns, infos


def report(label, status, outcome, feats, crs, err, fails, warns, infos, verbose):
    head = f"[{status}] {label}"
    if outcome == "ok":
        head += f"  crs={crs}  features={len(feats)}"
    elif err:
        head += f"  ->  {outcome}: {err}"
    print(head)
    if verbose and feats:
        for f in feats:
            print(f"      #{f['feature_index']:<2} {str(feature_name(f)):32.32s} {f['geometry_type']:16s} "
                  f"{fmt_measure(f):28s} {f['note'] or ''}")
    for m in fails:
        print("      FAIL:", m)
    for m in warns:
        print("      WARN:", m)
    if verbose:
        for m in infos:
            print("      info:", m)


def synthetic_tests():
    """Inputs too big to ship as files, generated on the fly."""
    def bomb():
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            with zf.open("big.shp", "w", force_zip64=True) as w:
                chunk = b"\0" * (1024 * 1024)
                for _ in range(201):
                    w.write(chunk)
        buf.seek(0)
        return buf

    return [
        ("[synthetic] 51 MB upload (size limit)", "big.kml", lambda: ZeroStream(50 * 1024 * 1024 + 1), ["too large"]),
        ("[synthetic] zip bomb (201 MB uncompressed)", "bomb.zip", bomb, ["too large when uncompressed"]),
        ("[synthetic] .geojson extension", "data.geojson", lambda: io.BytesIO(b"{}"), ["Unsupported file type"]),
    ]


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    verbose = "-v" in sys.argv
    expected = json.loads((SAMPLES / "expected.json").read_text(encoding="utf-8"))
    counts = {"PASS": 0, "WARN": 0, "FAIL": 0}

    for fname in sorted(expected):
        if args and not any(fname.startswith(a) for a in args):
            continue
        with open(SAMPLES / fname, "rb") as fh:
            outcome, feats, crs, err = run_one(fname, fh)
        fails, warns, infos = evaluate(expected[fname], outcome, feats, crs, err)
        status = "FAIL" if fails else "WARN" if warns else "PASS"
        counts[status] += 1
        report(fname, status, outcome, feats, crs, err, fails, warns, infos, verbose)

    if not args:
        for label, fname, make, contains in synthetic_tests():
            outcome, feats, crs, err = run_one(fname, make())
            exp = {"outcome": "error", "error_contains": contains}
            fails, warns, infos = evaluate(exp, outcome, feats, crs, err)
            status = "FAIL" if fails else "PASS"
            counts[status] += 1
            report(label, status, outcome, feats, crs, err, fails, warns, infos, verbose)

    print(f"\n{counts['PASS']} passed, {counts['WARN']} warnings, {counts['FAIL']} failed")
    sys.exit(1 if counts["FAIL"] else 0)


if __name__ == "__main__":
    main()
